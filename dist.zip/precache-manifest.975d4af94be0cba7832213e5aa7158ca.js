self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "fce8a8ca401788e20557",
    "url": "css/about.606a46d3.css"
  },
  {
    "revision": "755c7934aff07ef14dfd",
    "url": "css/chunk-vendors.598651dc.css"
  },
  {
    "revision": "4f7a9a93c267d98e971f3673d67bda03",
    "url": "img/bce.4f7a9a93.svg"
  },
  {
    "revision": "63a7d78d42c33b94fc7b957524795cac",
    "url": "img/logo.63a7d78d.svg"
  },
  {
    "revision": "7af26310f2cc5977e23aa70d06cfce7b",
    "url": "img/ocrspace.7af26310.png"
  },
  {
    "revision": "b88581b223860481cf7943006805a4cd",
    "url": "index.html"
  },
  {
    "revision": "fce8a8ca401788e20557",
    "url": "js/about.87767148.js"
  },
  {
    "revision": "05c5df3ecda623d503fd",
    "url": "js/app.73148341.js"
  },
  {
    "revision": "755c7934aff07ef14dfd",
    "url": "js/chunk-vendors.c66b355c.js"
  },
  {
    "revision": "2d52fca0e85cd7f8635947ea8d8487af",
    "url": "manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "robots.txt"
  }
]);